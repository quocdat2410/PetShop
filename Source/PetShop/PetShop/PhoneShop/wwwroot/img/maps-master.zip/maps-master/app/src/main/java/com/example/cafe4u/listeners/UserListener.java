package com.example.cafe4u.listeners;

import com.example.cafe4u.models.User;

public interface UserListener {
    void onUserClicked(User user);
}
