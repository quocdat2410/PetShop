package com.example.cafe4u.models;

import java.io.Serializable;

public class User implements Serializable {
    public String name, email, image, token, id;

}
