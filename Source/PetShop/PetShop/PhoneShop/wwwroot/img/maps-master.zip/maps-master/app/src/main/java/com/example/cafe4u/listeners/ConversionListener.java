package com.example.cafe4u.listeners;

import com.example.cafe4u.models.User;

public interface ConversionListener {
    void onConversionClicked(User user);
}
