package com.example.cafe4u.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.cafe4u.R;

public class ShopDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shop_detail);
    }
}